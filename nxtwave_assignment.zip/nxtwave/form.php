<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>contact Registration Form</title>
   
</head>

<body>
    <div class="container">
        <h1>contact Registration</h1>
        <form action="db.php" name ="" method="post">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your name" required>
            </div>

        <div class="form-group">
                <label for="mobileno">Mobile Number</label>
                <input type="tel" id="mobileno" name="mobileno" placeholder="Enter your mobile number" required>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" placeholder="Enter your email" required>
            </div>

            <div class="form-group">
                <input type="submit" name="register" value="Register"/>
            </div>
        </form>
    </div>
</body>
</html>
