<?php
$con = mysqli_connect("localhost", "root", "", "nxtwave");

if($con->connect_error){
    die("connection failed for retrive");
}

$query = "select * from contact";
$result =$con->query($query);


if($result -> num_rows > 0){
    ?>
	
   <table style="border:1px solid green; padding:10px">
	<thead >
		<tr style="border:1px solid green; padding:10px">
		  <th style="border:1px solid green; ">S.NO</th>
		  <th style="border:1px solid green; ">name</th>
		
          <th style="border:1px solid green; ">mobileno</th>
          <th style="border:1px solid green; ">email</th>
		  <th style="border:1px solid green; ">Action</th>
		</tr>
	</thead>

	  <tbody><?php
	  $i=1;
      while($row=$result ->fetch_assoc()){
			?>
			<tr>
				
				<td style="border:1px solid green; "><?=$i?></td>
				<td style="border:1px solid green; "><?=$row["name"]?></td>
				<td style="border:1px solid green; "><?=$row["mobileno"]?></td>
				<td style="border:1px solid green; "><?=$row["email"]?></td>
				<td style="border:1px solid green; ">
					<a href="update.php?id=<?php echo $row['id']?>"><button >Update</button></a>
					<a href="delete.php?id=<?=$row['id']?>" ><button >Delete</button></a>
			 	</td>
			</tr>
	  <?php
	  $i++;
	  }
	  ?>
</table>
<?php
}?>