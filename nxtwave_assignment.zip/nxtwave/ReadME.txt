db.php file is used to perfron insert and update operations on the database. 

=>If you want to run the code, you need to have a database with the same schema as the one in the code.

=>$con=mysqli_connect("localhost","root","","nxtwave"); Change these Parameters to your requirement as ('locahost','db username','db password','db name')
  (Must change the above line in all files where it was present to work correctly)

  
=>You can directly import the data for the data base using my attached nxtwave sql file.