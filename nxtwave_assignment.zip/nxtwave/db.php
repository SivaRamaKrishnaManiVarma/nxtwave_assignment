<?php
  $con = mysqli_connect("localhost","root","","nxtwave");
  if(!$con){
    die("Connection failed: " . mysqli_connect_error());
  }
  if(isset($_POST['register'])){
    $name= $_POST['name'];
    $mobileno = $_POST['mobileno'];
    $email = $_POST['email'];

    $query= "INSERT INTO contact (name,mobileno,email) VALUES ('$name','$mobileno','$email')";
    $result = $con->query($query);
   
    if($result){
        echo "Data inserted";
        ?>
        <br/>
        <a href="form.php"><button style="border: 1px solid green;">Add Customer</button></a>
        <a href="retrive.php"><button style="border: 1px solid green;">View Customer Table</button></a>
        <?php
    } else{
        echo "Error: " . $query . "<hr/>" . $con->error;
    }
  }


  if(isset($_POST["update_data"])){ // We use isset for checking whether the submitted button named as update_data or not
    
    $id = $_POST['id'];
    


    $query = "UPDATE contact SET 
              name='$_POST[name]', 
              mobileno='$_POST[mobileno]', 
              email='$_POST[email]' 
              WHERE id='$id'";

    $result = $con->query($query);

    if($result){
        echo "Data updated";?>
        <br/>
        <a href="form.php"><button style="border: 1px solid green;">Add contact Data</button></a>
        <a href="retrive.php"><button style="border: 1px solid green;">View contact Table</button></a>
        <?php
    } else {
        echo "Error: " . $query . "<br/>" . $con->error;
    }
}
?>