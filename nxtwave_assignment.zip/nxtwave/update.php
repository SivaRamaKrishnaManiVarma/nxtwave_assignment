<?php
$id = $_GET['id'];
//step1
$con=mysqli_connect("localhost","root","","nxtwave");
//step2
if($con->connect_error){
    die("Connection failed: " . $con->connect_error);
}
//step3
$query = "SELECT * FROM contact where id = '$id'";
$result = $con->query($query);

$row = $result->fetch_assoc();
?>
<!-- style  -->

<body>
    <div class="container">
        <h1>contact Updataion</h1>
        <form action="db.php" name ="" method="post">
        <input type="hidden" name="id" value="<?=$row['id'];?>" /><!--Hidden Beacaue The user doesn't need to know What his ID is-->

            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" placeholder="Enter your updated name " required>
                <span>Previous Name:<?=$row['name']?></span>
            </div>

       


            <div class="form-group">
                <label for="mobileno">Mobile Number</label>
                <input type="tel" id="mobileno" name="mobileno" placeholder="Enter your mobile number" required>
                <span>Previous mobileno: <?= $row['mobileno']?></span>
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="text" id="email" name="email" placeholder="Enter your  email" required>
                <span>Previous email: <?= $row['email']?></span>

            </div>

            <div class="form-group">
                <input type="submit" name="update_data" value="Update contact"/>
            </div>
        </form>
    </div>
</body> 