<?php
$id =$_GET['id'];

$con=new mysqli('localhost','root','','nxtwave');

if($con->connect_error){
	die("Connection Failed");
}
$query="DELETE FROM contact Where id='$id'"; 

$result =$con->query($query);
if($result){
		echo "Successfully Deleted";
		?>
		<div style="display-flex">
		<a href="form.php"><button >Add contact Data</button></a>
		<a href="retrive.php"><button >View contact Data</button></a>

	<div>
		<?php
	}else{
		
		echo "Error ".$sql ."<br>".$con->error;
	}
?>
